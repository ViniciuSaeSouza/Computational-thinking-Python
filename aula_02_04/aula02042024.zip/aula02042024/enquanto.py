
import os
os.system("clear")

volta = 1

# ------------------- inicio do laço
while volta <= 5:
    print("Bom dia!")
    volta = volta + 1
# ------------------- final do laço

print("Terminou")